audiogramsluhov — frontend static site
Deploy to Vercel or Netlify as a static project.

Files included:
- index.html : single-page app (no build step)

Usage:
1. Upload files to your Vercel project (as static site) or simply host index.html.
2. Open the site and paste your backend URL (Render public URL).
3. Upload an audiogram image and press 'Проанализировать и подобрать'.

Note: the link 'Скачать Audifon каталог' in the page points to:
file:///mnt/data/Технологии и модельный ряд audifon.pdf
If you want that catalog publicly available, upload the PDF to the same hosting or another public URL and update the href in index.html.
